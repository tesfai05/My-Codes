package lms.dataaccess;

public interface DAO {
	public void saveChange();
	public void addNew(DAO obj);
	public void edit(DAO obj);
	public void delete(DAO obj);
	
}
