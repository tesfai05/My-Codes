package lms.dataaccess;

import java.util.HashMap;

import lms.business.Address;
import lms.business.Author;
import lms.business.Book;
import lms.business.BookCopy;
import lms.business.CheckoutRecord;
import lms.business.LibraryMember;
import lms.dataaccess.DataAccessFacade.StorageType;
import lms.utils.saveMode;

public interface DataAccess { 
	public HashMap<String,Book> readBooksMap();
	public HashMap<String,User> readUserMap();
	public HashMap<String, LibraryMember> readMemberMap();
	public HashMap<String, Author> readAuthorMap();
	
	public void saveMember(LibraryMember member);
	
	public void deleteMemberFromDatabase(LibraryMember member);
	public void saveAuthor(Author m);
	public void deleteAuthorFromDatabase(Author author);
	public void saveBook(Book m);
	public void deleteBookFromDatabase(Book book);
	public HashMap<String, CheckoutRecord> readCheckOutRecordsMap();
	public void SaveCheckOutRecord(CheckoutRecord checkoutRecord);

}
