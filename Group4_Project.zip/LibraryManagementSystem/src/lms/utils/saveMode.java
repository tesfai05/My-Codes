package lms.utils;

public enum saveMode {
	NEW,EDIT,DELETE,CLOSE;
}
