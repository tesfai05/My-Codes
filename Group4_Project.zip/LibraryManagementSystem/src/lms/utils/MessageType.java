package lms.utils;

public enum MessageType{
	SUCCESS,ERROR,INFORMATION,CONFIRMATION, ;
}