package lms.utils;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import lms.ui.formListMembers;


public class Libraries {
	
	public static void showAlert(String header, String message, MessageType type, Object o) {
		String messageInfo="Confirmation";

		Alert alert = new Alert((messageInfo.equals(type.name())) ? AlertType.CONFIRMATION : AlertType.INFORMATION);
	        alert.setTitle("Labrary Management System");
	        
	        if(header != null)
	        	alert.setHeaderText(header);
	        alert.setContentText(message);
	        
	        alert.showAndWait();
	    
	}
	
	public static void loadStage(ActionEvent event,Class<?> c,String urlPath,String formName) throws IOException {
		Parent mainRoot;
 		Scene MasterScene;
 		// This will get the stage information
 		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
 		mainRoot = FXMLLoader.load(c.getClass().getResource(urlPath));
		MasterScene = new Scene(mainRoot, 600, 400);
		
 	 
		window.setScene(MasterScene);
		if (formName.isEmpty()) {
		 formName="Asmara Public Center"	;
		}
		window.setTitle(formName);
		window.show();
	}
}
