package lms.business;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lms.business.BookCopy;
import lms.business.BusinessFactoryClass;
import lms.business.CheckoutEntry;
import lms.business.Book;
import lms.dataaccess.Auth;
import lms.dataaccess.DataAccess;
import lms.dataaccess.DataAccessFacade;
import lms.dataaccess.User;
import lms.utils.Libraries;
import lms.utils.MessageType;

public class SystemController implements ControllerInterface {
	public static Auth currentAuth = null;
	public static User currentUser=null; 
	
	public void login(String id, String password) throws LoginException {
		DataAccess da = new DataAccessFacade();
		HashMap<String, User> map = da.readUserMap();
		if(!map.containsKey(id)) {
			throw new LoginException("UserName:" + id + " not found.");
		}
		String passwordFound = map.get(id).getPassword();
		if(!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
		currentAuth = map.get(id).getAuthorization();
		//currentUser
		currentUser=map.get(id);
	}
	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}
	
	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}
	
	@Override
	public LibraryMember createMember(String memberId, String firstName, String lastName, String phone, Address address) {
	   LibraryMember m=BusinessFactoryClass.getLibraryMemberInstance(memberId, firstName, lastName,phone,address);
	    
	    DataAccess access=new DataAccessFacade();
		access.saveMember(m);
		return m;
	}
	@Override
	public Address createAddress(String street, String city, String state, String zip) {
		  Address m=BusinessFactoryClass.getAddressInstance(street, city, state,zip);
		 
		return m;
	}
	@Override
	public LibraryMember searchMemberById(String memberID) {
		DataAccess da = new DataAccessFacade();
		LibraryMember m=null;
		HashMap<String,LibraryMember> allmembers=da.readMemberMap();
		if (allmembers.containsKey(memberID)) {
			m=allmembers.get(memberID);
		}
		
		return m;
	}
	@Override
	public LibraryMember editMember(LibraryMember m) {
	    DataAccess access=new DataAccessFacade();
			access.saveMember(m);
			return m;
	}
	@Override
	public List<LibraryMember> allMembers() {
		DataAccess da = new DataAccessFacade();
		
		HashMap<String,LibraryMember> allmembers=da.readMemberMap();
		List<LibraryMember> m=new ArrayList<>();
		
		allmembers.forEach((k,v)->{m.add(v);});
		
		return m;
	}
	//@Override
//	public BookCopy[] createBookCopy(String isbn, int addCopiesOf, boolean avalibility) {
//		DataAccess access=new DataAccessFacade();
//		
//		BookCopy[] m=BusinessFactoryClass.getBookCopyInstance(access.readBooksMap().get(isbn), addCopiesOf,avalibility);
//		    
//		
//        access.saveBookCopy(m);
//	    return m;
//	
//	}
	@Override
	public List<Book> allbooks() {
		DataAccess access=new DataAccessFacade();
		List<Book> b=new ArrayList<>();
		access.readBooksMap().forEach((e,v)->{
		b.add(v);
		});
		return b;
	}
	@Override
	public Book getBookByISBN(String isbn) {
		DataAccess access=new DataAccessFacade();
		
		return access.readBooksMap().get(isbn);
	}
	@Override
	public void deleteMember(LibraryMember member) {
		DataAccess access=new DataAccessFacade();
		access.deleteMemberFromDatabase(member);
		//return access.readBooksMap().get(isbn);
		
	}
	@Override
	public Author searchAuthorById(String authorId) {
		DataAccess da = new DataAccessFacade();
		Author m=null;
		HashMap<String,Author> allAuthor=da.readAuthorMap();
		if (allAuthor.containsKey(authorId)) {
			m=allAuthor.get(authorId);
		}
		return m;
	}
	@Override
	public Author createAuthor(String authorId, String firstName, String lastName, String phone, Address address,String bio) {
		 Author m=BusinessFactoryClass.getAuthorInstance(authorId, firstName, lastName,phone,address,bio);
		    
		    DataAccess access=new DataAccessFacade();
			access.saveAuthor(m);
			return m;
	}
	@Override
	public void editAuthor(Author author) {
		  DataAccess access=new DataAccessFacade();
			access.saveAuthor(author);
		
	}
	@Override
	public void deleteAuthor(Author author) {
		DataAccess access=new DataAccessFacade();
		access.deleteAuthorFromDatabase(author);
		
	}
	@Override
	public Book searchBookById(String isbn) {
		DataAccess da = new DataAccessFacade();
		Book m=null;
		HashMap<String,Book> allBooks=da.readBooksMap();
		if (allBooks.containsKey(isbn)) {
			m=allBooks.get(isbn);
		}
		return m;
	}
	@Override
	public Book createbook(String bookId, String title, int max,int addCopiesOf, List<Author> authors) {
		    Book m=BusinessFactoryClass.getBookInstance(bookId, title, max,authors);
		    if (addCopiesOf!=0) {
				for (int i = 0; i < addCopiesOf-1; i++) {
					m.addCopy();
				}
			}
		    DataAccess access=new DataAccessFacade();
			access.saveBook(m);
			return m;
	}
	@Override
	public void editbook(Book book) {
		  DataAccess access=new DataAccessFacade();
			access.saveBook(book);
		
	}
	@Override
	public void deletebook(Book book) {
		DataAccess access=new DataAccessFacade();
		access.deleteBookFromDatabase(book);
		
	}
	@Override
	public List<Author> allAuthors() {
        DataAccess da = new DataAccessFacade();
		
		HashMap<String,Author> allAuthors=da.readAuthorMap();
		List<Author> m=new ArrayList<>();
		
		allAuthors.forEach((k,v)->{m.add(v);});
		
		return m;
	}
	
	@Override
	public boolean checkoutBook(Book b, LibraryMember member) {
		
		BookCopy bc = null;
		bc = b.getNextAvailableCopy();
		
		if(bc == null)
			return false;
		
		bc.changeAvailability();
		CheckoutEntry ce = BusinessFactoryClass.getCheckoutEntryInstance(bc);
		//member.setCheckoutRecord(ce);
		member.getCheckoutRecord().addChecoutEntry(ce);
		
		//System.out.println(member.getCheckoutRecord());
		DataAccess access=new DataAccessFacade();
		
		access.saveBook(b);
		access.saveMember(member);
		access.SaveCheckOutRecord(member.getCheckoutRecord());
		
		return true;
	}
	public static String getAutoGeneratedLibraryMemberId() {
		DataAccess da=new DataAccessFacade();
		int maxId = 0;
		
		for(Map.Entry<String, LibraryMember> entry : da.readMemberMap().entrySet()) 
		{
			if(Integer.parseInt(entry.getValue().getMemberId()) > maxId) 
				maxId = Integer.parseInt(entry.getValue().getMemberId());
		}
		maxId=Math.abs(Integer.valueOf(maxId+1));
		return String.format("%s",maxId);
	}
	public static String getAutoGeneratedBookId() {
		DataAccess da=new DataAccessFacade();
		int maxId = 0;
		
		for(Map.Entry<String, Book> entry : da.readBooksMap().entrySet()) 
		{
			if(Integer.parseInt(entry.getValue().getIsbn()) > maxId) 
				maxId = Integer.parseInt(entry.getValue().getIsbn());
		}
		maxId=Math.abs(Integer.valueOf(maxId+1));
		return String.format("%s",maxId);
	}
	public static String getAutoGeneratedAuthorId() {
		DataAccess da=new DataAccessFacade();
		int maxId = 0;
		
		for(Map.Entry<String, Author> entry : da.readAuthorMap().entrySet()) 
		{
			if(Integer.parseInt(entry.getValue().getAuthorId()) > maxId) 
				maxId = Integer.parseInt(entry.getValue().getAuthorId());
		}
		maxId=Math.abs(Integer.valueOf(maxId+1));
		return String.format("%s",maxId);
	}
	public boolean findLibraryMemberByIdAndPrintCheckoutRecord(String id) {
		
		LibraryMember temp = null;
		temp = searchMemberById(id);
		
		if(temp == null) return false;
		//to the console
		printCheckoutRecordOfLibraryMember(temp);
		return true;
		
	}
public String findLibraryMemberByIdAndPrintCheckoutRecordToUI(String id) {
		
		LibraryMember temp = null;
		temp = searchMemberById(id);
		
		if(temp == null) return null;
		//to the console
		
		return printCheckoutRecordOfLibraryMember(temp);
		
	}
	
	public static String printCheckoutRecordOfLibraryMember(LibraryMember member) {
		StringBuilder s=new StringBuilder();
		s.append(member.toString());
		s.append("\n");
		System.out.println(member.toString());
		CheckoutRecord record = member.getCheckoutRecord();
		
		s.append("--------------------------------------------------------------------------------\n");
		
		System.out.println("--------------------------------------------------------------------------------");
		
		s.append(String.format("%-29s %8s %13s %13s %13s  %n", "Book Title", "Copy No", "Borrow Date", "Due Date", "Return Date"));
		
		System.out.printf("%-29s %8s %13s %13s %13s  %n", "Book Title", "Copy No", "Borrow Date", "Due Date", "Return Date");
		System.out.println("--------------------------------------------------------------------------------");
		for(CheckoutEntry c : record.getEntries()) {
			System.out.printf("%-29s %8s %13s %13s %13s  %n",c.getBookCopy().getBook().getTitle(), 
					                                     c.getBookCopy().getCopyNum(),
					                                     c.getBorrowDate().toLocalDate().toString(),
					                                     c.getDueDate().toLocalDate().toString(),
					                                     (c.getReturnDate() == null) ? "-" : c.getReturnDate().
				                                    		                             toLocalDate().toString());
          s.append(String.format("%-29s %13s %15s %17s %19s  %n",c.getBookCopy().getBook().getTitle(), 
					                                     c.getBookCopy().getCopyNum(),
					                                     c.getBorrowDate().toLocalDate().toString(),
					                                     c.getDueDate().toLocalDate().toString(),
					                                     (c.getReturnDate() == null) ? "-" : c.getReturnDate().
					                                    		                             toLocalDate().toString()));
          s.append("--------------------------------------------------------------------------------");
			System.out.println("--------------------------------------------------------------------------------");
		}
		return s.toString();
	}
	public static String printOverDueBooksByLibraryMember(LibraryMember member) {
		StringBuilder s=new StringBuilder();
		s.append(member.toString());
		s.append("\n");
		System.out.println(member.toString());
		CheckoutRecord record = member.getCheckoutRecord();
		
		s.append("--------------------------------------------------------------------------------\n");
		
		System.out.println("--------------------------------------------------------------------------------");
		
		s.append(String.format("%-29s %8s %13s %13s %13s  %n", "Book Title", "Copy No", "Borrow Date", "Due Date", "Return Date"));
		
		System.out.printf("%-29s %8s %13s %13s %13s  %n", "Book Title", "Copy No", "Borrow Date", "Due Date", "Return Date");
		System.out.println("--------------------------------------------------------------------------------");
		for(CheckoutEntry c : record.getListOfUnreturnedBooks()) {
			if (c.checkOverDue()) {
				System.out.printf("%-29s %8s %13s %13s %13s  %n",c.getBookCopy().getBook().getTitle(), 
                        c.getBookCopy().getCopyNum(),
                        c.getBorrowDate().toLocalDate().toString(),
                        c.getDueDate().toLocalDate().toString(),
                        (c.getReturnDate() == null) ? "-" : c.getReturnDate().
                   		                             toLocalDate().toString());
s.append(String.format("%-29s %13s %15s %17s %19s  %n",c.getBookCopy().getBook().getTitle(), 
                        c.getBookCopy().getCopyNum(),
                        c.getBorrowDate().toLocalDate().toString(),
                        c.getDueDate().toLocalDate().toString(),
                        (c.getReturnDate() == null) ? "-" : c.getReturnDate().
                       		                             toLocalDate().toString()));
			}
			
          s.append("--------------------------------------------------------------------------------");
			System.out.println("--------------------------------------------------------------------------------");
		}
		return s.toString();
	}
	
	public boolean findLibraryMemberByIdAndPrintOverDue(String id) {
		
		LibraryMember temp = null;
		temp = searchMemberById(id);
		
		if(temp == null) return false;
		//to the console
		printOverDueBooksByLibraryMember(temp);
		return true;
		
	}
public String findLibraryMemberByIdAndPrintOverDueToUI(String id) {
		
		LibraryMember temp = null;
		temp = searchMemberById(id);
		
		if(temp == null) return null;
		//to the console
		
		return printOverDueBooksByLibraryMember(temp);
		
	}
	@Override
	public List<String> allAuthorsId() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readAuthorMap().keySet());
		return retval;
	}
	@Override
	public boolean saveCheckOutBook(LibraryMember member) {
		DataAccess access=new DataAccessFacade();
		access.saveMember(member);
		
		access.SaveCheckOutRecord(member.getCheckoutRecord());
		
		return true;
	}
}
