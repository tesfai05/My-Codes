package lms.business;

import java.io.Serializable;

public enum EmployeeType implements Serializable{

	ADMIN, LIBRARIAN, BOTH;
	
	@Override
	public String toString() {
		return (this.equals(ADMIN)) ? "ADMIN" : (this.equals(LIBRARIAN)) ? "LIBRARIAN" : "BOTH";
	}
	
}
