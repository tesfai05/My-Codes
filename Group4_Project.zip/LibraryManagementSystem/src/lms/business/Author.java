package lms.business;

import java.io.Serializable;

final public class Author extends Person implements Serializable {
	private String bio;
	private String authorId;
	public String getBio() {
		return bio;
	}
	

	public void setBio(String bio) {
		this.bio = bio;
	}

	public Author(String authorId,String f, String l, String t, Address a, String bio) {
		super(f, l, t, a);
		this.authorId=authorId;
		this.bio = bio;
	}
    public String getAuthorId() {
    	return authorId;
    }
    
    
	@Override
	public String toString() {
		return "authorId=" + authorId + ", FirstName=" + this.getFirstName()+", LastName=" +this.getLastName();
	}


	private static final long serialVersionUID = 7508481940058530471L;

}
