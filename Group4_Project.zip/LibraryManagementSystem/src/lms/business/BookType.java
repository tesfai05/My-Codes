package lms.business;

import java.io.Serializable;

public enum BookType implements Serializable{

	BOOK, PERODICAL
	
}
