package lms.business;

import java.util.List;
import java.io.Serializable;
import java.util.ArrayList;

public final class CheckoutRecord  implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 9121276943918917687L;
	

	private List<CheckoutEntry> entries;
	private LibraryMember member;
	
	CheckoutRecord(LibraryMember member){
		this.member = member;
		entries = new ArrayList<CheckoutEntry>();
	}

	public List<CheckoutEntry> getEntries() {
		return entries;
	}
	
	public LibraryMember getLibraryMember() {
		return member;
	}
	
	public void addChecoutEntry(CheckoutEntry checkoutEntry) {
		entries.add(checkoutEntry);
	}
	
	public int getNumberOfUnreturnedBooks() {
		int count = 0;
		
		for(CheckoutEntry c : entries) {
			if(c.getReturnDate() == null)
				++count;
		}
		
		return count;
	}
	
	public List<CheckoutEntry> getListOfUnreturnedBooks(){
		List<CheckoutEntry> unreturned = new ArrayList<CheckoutEntry>();
		
		for(CheckoutEntry c : entries) {
			if(c.getReturnDate() == null)
				unreturned.add(c);
		}
		
		return unreturned;
	}
	@Override
	public String toString() {
		return "CheckoutRecord [entries=" + entries + ", member=" + member + "]";
	}
	@Override
	public boolean equals(Object o) {
		
		if(o == this) return true;
		
		if(o == null) return false;
		
		if(!(o instanceof CheckoutRecord)) return false;
		
		CheckoutRecord c = (CheckoutRecord) o;
		
		return entries.equals(c.entries) &&
			   member.equals(c.member);
		
	}
}
