package lms.business;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public final class CheckoutEntry implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4908733956042333556L;
	private BookCopy bookCopy;
	private LocalDateTime borrowDate;
	private LocalDateTime dueDate;
	private LocalDateTime returnDate;
	private boolean fine;
	//private LibraryMember libraryMember;
	
	CheckoutEntry(BookCopy bookCopy){
		this.bookCopy = bookCopy;
		this.borrowDate = LocalDateTime.now();
		this.dueDate = calculateDueDate();
		this.fine = false;
	}

	public CheckoutEntry(BookCopy bookCopy, LibraryMember member, LocalDate borrorwDate, LocalDate dueDate,
			LocalDate returnDate, boolean fine) {
		this.bookCopy = bookCopy;
		this.borrowDate = LocalDateTime.now();
		this.dueDate = calculateDueDate();
		this.fine = false;
	}

//	CheckoutEntry setLibraryMember(LibraryMember libraryMember) {
//		this.libraryMember = libraryMember;
//		return this;
//	}
	
	public BookCopy getBookCopy() {
		return bookCopy;
	}

	public LocalDateTime getBorrowDate() {
		return borrowDate;
	}

	public LocalDateTime getReturnDate() {
		return returnDate;
	}

	public LocalDateTime getDueDate() {
		return dueDate;
	}

	public void setReturnDate(LocalDateTime returnDate) {
		this.returnDate = returnDate;
	}
	public void setFine(LocalDateTime returnDate) {
		this.returnDate = returnDate;
	}
	public boolean checkOverDue() {
		if(returnDate == null &&
		   LocalDateTime.now().compareTo(dueDate) > 0) {
			setFine(true);
			return true;
		}
		return false;
	}
	
	boolean isFine() {
		return fine;
	}

	public void setFine(boolean fine) {
		this.fine = fine;
	}
	
	private LocalDateTime calculateDueDate() {
		return borrowDate.plusDays(bookCopy.getBook().getMaxCheckoutLength());
	}
	
	@Override
	public String toString() {
		return "Book Title: " + bookCopy.getBook().getTitle() +
			   //"Copy No: " + bookCopy.getCopyId() +
			   "Borrow Date: " + borrowDate +
			   "Due Date: " + dueDate +
			   "Return Date: " + (returnDate == null ? "Not Returned" : returnDate) + 
			   "Fine: " + fine;
	}
	
	@Override
	public boolean equals(Object o) {
		
		if(o == this) return true;
		
		if(o == null) return false;
		
		if(!(o instanceof CheckoutEntry)) return false;
		
		CheckoutEntry c = (CheckoutEntry) o;
		
		return bookCopy.equals(c.bookCopy) &&
			   borrowDate.equals(c.borrowDate);
		
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(bookCopy, borrowDate);
	}

}
