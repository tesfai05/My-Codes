package lms.business;

import java.util.List;

import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import lms.business.Book;
import lms.dataaccess.DataAccess;
import lms.dataaccess.DataAccessFacade;

public interface ControllerInterface {
	public void login(String id, String password) throws LoginException;
	public List<String> allMemberIds();
	public List<String> allBookIds();
	public List<String> allAuthorsId();
	public List<LibraryMember> allMembers();
	public List<Author> allAuthors();
	public List<Book> allbooks();
	public Book getBookByISBN(String isbn);
	
	public LibraryMember searchMemberById(String memberID);
	public LibraryMember createMember(String memberId,String firstName,String lastName,String phone,Address address) throws LibrarySystemException;
    public LibraryMember editMember(LibraryMember m);
	public Address createAddress(String street,String city,String state,String zip) throws LibrarySystemException;
	
	public void deleteMember(LibraryMember member);
	public Author searchAuthorById(String authorId);
	public Author createAuthor(String authorId, String firstName, String lastName, String phone, Address address,String bio);
	public void editAuthor(Author author);
	public void deleteAuthor(Author author);
	public Book searchBookById(String isbn);
	public Book createbook(String bookId, String title, int max,int addCopiesOf, List<Author> authors);
	public void editbook(Book book);
	public void deletebook(Book book);
	public boolean checkoutBook(Book b, LibraryMember member);
	public boolean saveCheckOutBook(LibraryMember member);
	public boolean findLibraryMemberByIdAndPrintCheckoutRecord(String mId);
	
	public String findLibraryMemberByIdAndPrintCheckoutRecordToUI(String mId);
	public boolean findLibraryMemberByIdAndPrintOverDue(String mid);
	public String findLibraryMemberByIdAndPrintOverDueToUI(String mid);
	
	
    
}
