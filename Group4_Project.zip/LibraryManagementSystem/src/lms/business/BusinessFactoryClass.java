package lms.business;

import java.time.LocalDate;
import java.util.List;


public class BusinessFactoryClass {

	
	public static LibraryMember getLibraryMemberInstance(String id, String firstName, String lastName,String tel, Address address) {
		return new LibraryMember(id, firstName, lastName,tel, address);
	}

	public static Address getAddressInstance(String street, String city, String state, String zip) {
		// TODO Auto-generated method stub
		return new Address(street, city, state,zip);
	}


	public static Author getAuthorInstance(String authorId, String firstName, String lastName, String phone,
			Address address, String bio) {
		return new Author(authorId, firstName, lastName,phone, address,bio);
	}

	public static Book getBookInstance(String bookId, String title, int max, List<Author> authors) {
		return new Book(bookId, title, max,authors);
	}

	public static CheckoutEntry getCheckoutEntryInstance(BookCopy bookCopy ) {
	
		return new CheckoutEntry(bookCopy);
	}

	public static CheckoutRecord getCheckoutRecordInstance(LibraryMember member1) {
		CheckoutRecord coe=new CheckoutRecord(member1);
		return coe;
	}


	
}
