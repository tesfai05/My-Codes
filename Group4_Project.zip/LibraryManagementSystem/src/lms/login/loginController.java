package lms.login;

import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Popup;
import javafx.stage.Stage;
import lms.business.ControllerInterface;
import lms.business.LoginException;
import lms.business.SystemController;
import lms.ui.formMainController;

public class loginController {
	@FXML
	private TextField userName;

	@FXML
	private TextField passWord;

	@FXML
	private Button btnlogin;

	@FXML
	private Text messageBar;
	
	public static class Colors {
		static Color green = Color.web("#034220");
		static Color red = Color.FIREBRICK;
	}

	@FXML // This Will login to master form for authenticated system users
	public void loginButtonClicked(ActionEvent event) throws IOException {

		String username = "";
		String password = "";

		username = userName.getText();
		password = passWord.getText();

		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		try {
			ControllerInterface c = new SystemController();
			c.login(userName.getText().trim(), passWord.getText().trim());
			messageBar.setFill(Color.web("#034220"));
			messageBar.setText("Login successful");

			//after loginsuccessfully open the main form
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/lms/ui/formMain.fxml"));
			mainRoot= loader.load();
//			formMainController cont = loader.getController();
//			cont.SetPermissions();
			
			
			MasterScene = new Scene(mainRoot, 600, 400);

			window.setScene(MasterScene);
			window.setTitle("Master Form");
			window.show();
			

		} catch (LoginException ex) {
			messageBar.setFill(Color.FIREBRICK);
			messageBar.setText("Error! " + ex.getMessage());
		}

	}

	// Exits from login form
	public void ExitButtonClicked(ActionEvent event) {

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

		window.close();

	}
}
