package lms.ui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.controlsfx.control.CheckListView;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MultipleSelectionModel;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import lms.business.Address;
import lms.business.Author;
import lms.business.Book;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.LibrarySystemException;
import lms.business.SystemController;
import lms.ui.formCheckOutBookController.CheckoutModel;

import lms.utils.Libraries;
import lms.utils.MessageType;

public class formBookController implements Initializable {
	formSelectAuthorController controller;
	@FXML
	private TextField txtISBN, txtTitle, txtSearch;
	@FXML
	private Text txtNumberOfCopies;
	@FXML
	private Button btnSave, btnEdit, btnDelete, btnCancel, btnAddAuthor, btnRemoveAuthor;

	@FXML
	private TextField txtAddCopiesOf;
	@FXML
	private ComboBox<String> cbMaxCheckoutDays;
	@FXML
	private Text messageBar;

	@FXML
	private TableView<BookDataModel> lvAuthors;

	@FXML
	private TableColumn<BookDataModel, String> idAuthorID;
	@FXML
	private TableColumn<BookDataModel, String> idFirstName;
	@FXML
	private TableColumn<BookDataModel, String> idlast;

	private String errorMessage;
	Book book;
	List<Author> selectedAuthors = new ArrayList<>();
    List<String> allAuthorsIds=new ArrayList<>();
    private String selectedAutherID;
    BookDataModel toBeRemoved;
	private String bookId;

	@FXML
	public void onKeypress(KeyEvent event) {

		if (event.getCode() == KeyCode.ENTER) {
			System.out.println(".........Searching Book .......");
			ControllerInterface ci = new SystemController();

			book = ci.searchBookById(txtSearch.getText());
			if (book != null) {
				setControls(book);

				System.out.println("Result found:");
				System.out.println(book);
				txtAddCopiesOf.setDisable(true);
			} else {
				txtAddCopiesOf.setDisable(false);
				clearAllFields();
				System.out.println("Searching result not found");
				txtAddCopiesOf.setDisable(false);
			}
		}

	}

	private void bindData(Book lm) {
		lm.setIsbn(txtISBN.getText());
		lm.setTitle(txtTitle.getText());
		bookId = lm.getIsbn();
		lm.setMaxCheckoutLength(Integer.parseInt(cbMaxCheckoutDays.getValue()));
		//All all the selected authors to list of authors
		ControllerInterface ci=new SystemController();
		for (String string : allAuthorsIds) {
			Author a=ci.searchAuthorById(string);
			selectedAuthors.add(a);
		}
		
		if (selectedAuthors!=null) {
			for (Author author : selectedAuthors) {
				book.addAuthor(author);
			}
		}
		lm.setAuthors(selectedAuthors);
		

	}

	private void setControls(Book lm) {
		txtISBN.setText(lm.getIsbn());
		bookId = lm.getIsbn();
		txtTitle.setText(lm.getTitle());
		cbMaxCheckoutDays.setValue(String.format("%s", lm.getMaxCheckoutLength()));
		txtNumberOfCopies.setText(String.format("Total Number Of Book Copies :%s", lm.getCopies().length));
		List<Author> authors = lm.getAuthors();
		allAuthorsIds.clear();
		selectedIds.clear();
		lvAuthors.getItems().clear();
		for (Author author : authors) {
			
			allAuthorsIds.add(author.getAuthorId());
			getItemsToAdd(author.getAuthorId());
			lvAuthors.getItems().setAll(selectedIds);
	
		
		}
	}

	@FXML // This Will enable to return back to master form
	public void onCancelEvent(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Asmara Public Library");
			window.show();

			// System.out.println("Login button clicked");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean showSelectionAuthor() {
		try {

			// Load the fxml file and create a new stage for the popup dialog.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(formBookController.class.getResource("/lms/ui/formSelectAuthor.fxml"));
			AnchorPane page = (AnchorPane) loader.load();

			// Create the dialog Stage.
			Stage dialogStage = new Stage();

			Scene scene = new Scene(page);
			dialogStage.setScene(scene);

			controller = loader.getController();
			controller.setDialogStage(dialogStage);

			dialogStage.showAndWait();

			return controller.isOkClicked();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	@SuppressWarnings("unlikely-arg-type")
	@FXML // This Will enable to return back to master form
	public void onAddAuthor(ActionEvent event) {
		if (showSelectionAuthor()) {
			if (controller != null) {
			
				//System.out.println(selectedIds.contains(controller.getSelectedAuthor()));
			if (allAuthorsIds.contains(controller.getSelectedAuthor())) return;
				allAuthorsIds.add(controller.getSelectedAuthor());
			getItemsToAdd(controller.getSelectedAuthor());
				lvAuthors.getItems().setAll(selectedIds);
		
			}

		}
	}

	@FXML // This Will enable to return back to master form
	public void onRemoveAuthor(ActionEvent event) {
		allAuthorsIds.remove(selectedAutherID);
		selectedIds.remove(toBeRemoved);
		lvAuthors.getItems().setAll(selectedIds);
	}

	private boolean isInputValid() {
		String errorMessage = "";

		if (txtTitle.getText() == null || txtTitle.getText().length() == 0) {
			errorMessage += "No valid first name!\n";
		}
		if (cbMaxCheckoutDays.getValue() == null ) {
			errorMessage += "No valid last name!\n";
		}
		if (txtAddCopiesOf.getText() == null || txtAddCopiesOf.getText().length() == 0) {
			errorMessage += "No valid first name!\n";
		}
	
		else {
			// try to parse the number of copies into an int.
			try {
				
				Integer.parseInt(txtAddCopiesOf.getText());
			} catch (NumberFormatException e) {
				errorMessage += "No valid number of copies(must be an integer)!\n";
			}
		}
		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			
			Libraries.showAlert("Invalid Fields", errorMessage, MessageType.ERROR, null);
		
			return false;
		}
	}

	@FXML // This Will enable to return back to master form
	public void AddButtonClicked(ActionEvent event) throws LibrarySystemException {
		System.out.println(".........Adding new book.......");
		if(!isInputValid()) return;
		bookId = txtISBN.getText();
		String title = txtTitle.getText();
		int addCopiesOf = 0;
		int max = Integer.parseInt(cbMaxCheckoutDays.getValue());
		if (!txtAddCopiesOf.getText().isEmpty()) {
			addCopiesOf = Integer.parseInt(txtAddCopiesOf.getText());
		}

		ControllerInterface ci = new SystemController();

		//All all the selected authors to list of authors
		for (String string : allAuthorsIds) {
			Author a=ci.searchAuthorById(string);
			selectedAuthors.add(a);
		}
		
		Book addedBook = ci.createbook(bookId, title, max, addCopiesOf, selectedAuthors);

		System.out.println(addedBook);
		Libraries.showAlert("Success", "Library book Inserted Successfully.", MessageType.CONFIRMATION, null);
		// clear all fields
		clearAllFields();
	}

	@FXML // This Will enable to return back to master form
	public void EditButtonClicked(ActionEvent event) {
		System.out.println("......Editing library book information.......");
		if(!isInputValid()) return;
		ControllerInterface ci = new SystemController();
	
		if (book != null) {
			
			bindData(book);
			ci.editbook(book);
			System.out.println("Data updated successfully....");
			System.out.println(book);
		} else {
			System.out.println("No data found to update.....");
		}
	}

	@FXML
	public void DeleteButtonClicked(ActionEvent event) {
		System.out.println(".........Deleting library book.......");
		ControllerInterface ci = new SystemController();
		if (book != null) {
			ci.deletebook(book);
			Libraries.showAlert("Delete Memeber", "Successfully Deleted", MessageType.CONFIRMATION, this);
			System.out.println(book);
			clearAllFields();
		} else {
			System.out.println("No data found to be deleted.");
		}
	}

	private void clearAllFields() {
		bookId = SystemController.getAutoGeneratedBookId();
		txtISBN.setText(bookId.toString());

		txtTitle.setText("");
		txtNumberOfCopies.setText("#");
		txtAddCopiesOf.setText("");
		cbMaxCheckoutDays.setValue("");
		selectedAuthors.clear();
		selectedIds.clear();
		lvAuthors.getItems().clear();
	}

	private ObservableList<Author> getInitialListData() {

		ControllerInterface c = new SystemController();
		List<Author> m = c.allAuthors();

		ObservableList<Author> data = FXCollections.observableList(m);

		return data;
	}

	private ObservableList<Author> getInitialAuthorsByBook(Book b) {

		ControllerInterface c = new SystemController();
		List<Author> m = b.getAuthors();

		ObservableList<Author> data = FXCollections.observableList(m);

		return data;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			cbMaxCheckoutDays.getItems().add("7");
			cbMaxCheckoutDays.getItems().add("21");
			lvAuthors.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
			bookId = SystemController.getAutoGeneratedBookId();
			txtISBN.setText(bookId.toString());
			txtISBN.setDisable(true);

			idAuthorID.setCellValueFactory(data -> data.getValue().AuthorIdProperty());
			// same here user naming convention
			idFirstName.setCellValueFactory(data -> data.getValue().firstNameProperty());
			idlast.setCellValueFactory(data -> data.getValue().lastNameProperty());
			
			lvAuthors.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Object>() {

				@Override
				public void changed(ObservableValue<?> observableValue, Object oldValue, Object newValue) {
			      try {
			    	  BookDataModel selectedItems = lvAuthors.getSelectionModel().getSelectedItems().get(0);
						if (selectedItems!=null) {
							selectedAutherID=selectedItems.getAuthorId();
							toBeRemoved=selectedItems;
						}
					} catch (Exception e) {
						// TODO: handle exception
					}
						
//				
				}
			});
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	
	}
	ObservableList<BookDataModel> selectedIds=FXCollections.observableArrayList();
	private ObservableList<BookDataModel> getItemsToAdd(String authorID) {

		ControllerInterface ci = new SystemController();
		Author list=ci.searchAuthorById(authorID);
		selectedIds.add(new BookDataModel(list.getAuthorId(),list.getFirstName(),list.getLastName()));
		return selectedIds;
	}
	class BookDataModel {
		private StringProperty AuthorId;

		public String getAuthorId() {
			return this.AuthorId.get();
		}

		public void setAuthorId(String AuthorId) {
			this.AuthorId.set(AuthorId);
		}

		public StringProperty AuthorIdProperty() {
			return this.AuthorId;
		}

		private StringProperty firstName;

		public String getfirstName() {
			return this.firstName.get();
		}

		public void setfirstName(String firstName) {
			this.firstName.set(firstName);
		}

		public StringProperty firstNameProperty() {
			return this.firstName;
		}

		private StringProperty lastName;

		public String getlastName() {
			return this.lastName.get();
		}

		public void setlastName(String lastName) {
			this.lastName.set(lastName);
		}

		public StringProperty lastNameProperty() {
			return this.lastName;
		}


		public BookDataModel(String AuthorId, String firstName, String lastName) {
			this.AuthorId = new SimpleStringProperty(AuthorId);
			this.firstName = new SimpleStringProperty(firstName);
			this.lastName = new SimpleStringProperty(lastName);
		}
		
	}
}
