package lms.ui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.stage.Stage;

public class formAboutController {
	@FXML
	private Button btnOk;
	@FXML // This Will enable to return back to master form
	public void onCancelEvent(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Asmara Public Library");
			window.show();

			// System.out.println("Login button clicked");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
