package lms.ui;

import java.util.Collections;
import java.util.List;
import java.util.Random;

import com.aeonium.javafx.validation.annotations.FXRequired;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import lms.business.Address;
import lms.business.BusinessFactoryClass;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.LibrarySystemException;
import lms.business.SystemController;
import lms.dataaccess.DAO;
import lms.dataaccess.DataAccess;
import lms.dataaccess.DataAccessFacade;
import lms.utils.Libraries;
import lms.utils.MessageType;

public class formMemberController {
	@FXML
	private TextField txtMemberID;

	@FXML
	@FXRequired(required = true, message = "Please provide name!")
	private TextField txtFirstName;
	
	@FXML
	private TextField txtLastName;

	@FXML
	private TextField txtPhoneNumber;
	@FXML
	private TextField txtStreet;
	@FXML
	private TextField txtCity;
	@FXML
	private TextField txtState;

	@FXML
	private TextField txtZip;
	@FXML
	private Button btnCancel;
	@FXML
	private Button btnLogin;
    @FXML
    private TextField txtSearch;
	@FXML 
	private Button btnEdit,btnDelete;
	@FXML 
	private Text messageBar;
	private String errorMessage;
	
    LibraryMember member;
    
	private String memberId;
	
	@FXML
	public void onKeypress(KeyEvent event) {
		
		if (event.getCode() == KeyCode.ENTER) {
			System.out.println(".........Searching library member.......");
			ControllerInterface ci = new SystemController();
			member = ci.searchMemberById(txtSearch.getText());
			if (member!=null) {
				setControlls(member);
				
				System.out.println("Result found:");
				System.out.println(member);
			}else {
				clearAllFields();
				System.out.println("Searching result not found");
			
			}
	    }
		
	}
	private boolean isInputValid() {
		String errorMessage = "";

		if (txtFirstName.getText() == null || txtFirstName.getText().length() == 0) {
			errorMessage += "No valid first name!\n";
		}
		if (txtLastName.getText() == null || txtLastName.getText().length() == 0) {
			errorMessage += "No valid last name!\n";
		}
		if (txtPhoneNumber.getText() == null || txtPhoneNumber.getText().length() == 0) {
			errorMessage += "No valid phoneNumber!\n";
		}
		if (txtStreet.getText() == null || txtStreet.getText().length() == 0) {
			errorMessage += "No valid street!\n";
		}

		if (txtCity.getText() == null || txtCity.getText().length() == 0) {
			errorMessage += "No valid city!\n";
			
		} 

		if (txtState.getText() == null || txtState.getText().length() == 0) {
			errorMessage += "No valid city!\n";
		}
		if (txtZip.getText() == null || txtZip.getText().length() == 0) {
			errorMessage += "No valid city!\n";
		}
		else {
			// try to parse the postal code into an int.
			try {
				//Integer.parseInt(txtPhoneNumber.getText());
				Integer.parseInt(txtZip.getText());
			} catch (NumberFormatException e) {
				errorMessage += "No valid zip code (must be an integer)!\n";
			}
		}
		if (errorMessage.length() == 0) {
			return true;
		} else {
			// Show the error message.
			
			Libraries.showAlert("Invalid Fields", errorMessage, MessageType.ERROR, null);
		
			return false;
		}
	}
	private void bindData(LibraryMember lm) {
		lm.setFirstName(txtFirstName.getText());
		lm.setLastName(txtLastName.getText());
		memberId=lm.getMemberId();
		lm.setTelephone(txtPhoneNumber.getText());
		lm.getAddress().setCity(txtCity.getText());
		lm.getAddress().setState(txtState.getText());
		lm.getAddress().setZip(txtZip.getText());
		lm.getAddress().setStreet(txtStreet.getText());
		//set for address also
		
	}
	private void setControlls(LibraryMember lm) {
		txtMemberID.setText(lm.getMemberId());
		memberId=lm.getMemberId();
		txtFirstName.setText(lm.getFirstName());
		txtLastName.setText(lm.getLastName());
		txtPhoneNumber.setText(lm.getTelephone());
		txtState.setText(lm.getAddress().getState());
		txtStreet.setText(lm.getAddress().getStreet());
		txtCity.setText(lm.getAddress().getCity());
		txtZip.setText(lm.getAddress().getZip());
	}
	@FXML // This Will enable to return back to master form
	public void onCancelEvent(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Asmara Public Library");
			window.show();

			// System.out.println("Login button clicked");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML // This Will enable to return back to master form
	public void AddButtonClicked(ActionEvent event) {
		System.out.println(".........Adding new library member.......");
		if (!isInputValid()) return; 
		memberId=txtMemberID.getText();
		String firstName = txtFirstName.getText();
		String lastName = txtLastName.getText();
		String phone = txtPhoneNumber.getText();
		String street = txtStreet.getText();
		String city = txtCity.getText();
		String state = txtState.getText();
		String zip = txtZip.getText();
		
		ControllerInterface ci = new SystemController();
		LibraryMember m=null;
		try {
			Address address=ci.createAddress(street, city, state, zip);
			m=ci.createMember(memberId, firstName, lastName, phone, address);
		} catch (LibrarySystemException e) {
			e.printStackTrace();
		}
		
		System.out.println(m);
		Libraries.showAlert("Success", "Library Member Inserted Successfully.", MessageType.CONFIRMATION,null);
			//clear all fields
		clearAllFields();
	}

	@FXML // This Will enable to return back to master form
	public void EditButtonClicked(ActionEvent event) {
		System.out.println("......Editing library member information.......");
		if (!isInputValid()) return; 
		ControllerInterface ci = new SystemController();
		if (member!=null) {
			
			bindData(member);
			ci.editMember(member);
			System.out.println("Data updated successfully....");
			System.out.println(member);
		}else
		{
			System.out.println("No data found to update.....");
		}
	}
	@FXML
	public void DeleteButtonClicked(ActionEvent event) {
		System.out.println(".........Deleting library member.......");
		ControllerInterface ci = new SystemController();
		if (member!=null) {
			ci.deleteMember(member);
			Libraries.showAlert("Delete Memeber", "Successfully Deleted", MessageType.CONFIRMATION, this);
			System.out.println(member);
			clearAllFields();
		}else
		{
			System.out.println("No data found to be deleted.");
		}

	}
	@FXML
	public void initialize() {
		
		memberId =SystemController.getAutoGeneratedLibraryMemberId();
		txtMemberID.setText(memberId);
		errorMessage="";
		txtMemberID.setEditable(false);
	
	}

	private void clearAllFields() {
		memberId = SystemController.getAutoGeneratedLibraryMemberId();
		txtMemberID.setText(memberId);
		txtFirstName.setText("");
		txtLastName.setText("");
		txtPhoneNumber.setText("");
		txtState.setText("");
		txtStreet.setText("");
		txtCity.setText("");
		txtZip.setText("");
	}

}
