package lms.ui;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.SystemController;
import lms.utils.Libraries;

public class formListMembers implements Initializable{
	 @FXML
     private TableView<DataModel> view;
     @FXML
     private Button btnLoadData;
     @FXML 
     private Button btnCancel;
     
     
     @FXML
     public void onCancel(ActionEvent event) throws IOException {
    	Parent mainRoot;
 		Scene MasterScene;
 		// This will get the stage information
 		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
 		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);
		
 	 
		window.setScene(MasterScene);
		window.setTitle("Asmara Public Library");
		window.show();
		
		//Libraries.loadStage(event, this, "/lms/ui/formMain.fxml", "Asmara Public Center");
     }
     @FXML
     private TableView<DataModel> myTableView;

     @FXML
     private TableColumn<DataModel, String> idColumn;
     @FXML
     private TableColumn<DataModel, String> idFirstName;
     @FXML
     private TableColumn<DataModel, String> idlastName;
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// use java naming conventions (`userId` instead of `UserId`)
		 idColumn.setCellValueFactory(data -> data.getValue().memberIdProperty()); 
		 // same here user naming convention
		 idFirstName.setCellValueFactory(data -> data.getValue().firstNameProperty());
		 idlastName.setCellValueFactory(data -> data.getValue().lastNameProperty());
		 
	     myTableView.getItems().setAll(getItemsToAdd());
	}


	private ObservableList<DataModel> getItemsToAdd() {

		ControllerInterface ci = new SystemController();
		List<LibraryMember> list=ci.allMembers();
		ObservableList<DataModel> ids = FXCollections.observableArrayList();
		
		for (LibraryMember l : list) {
			 ids.add(new DataModel(l.getMemberId(),l.getFirstName(),l.getLastName()));
		}
			
		return ids;
	}
	class DataModel{
		  private StringProperty memberID;

		    public String getMemberId() { return this.memberID.get(); }
		    public void setMemberId(String memberID) { this.memberID.set(memberID); }
		    public StringProperty memberIdProperty() { return this.memberID; }

		    private StringProperty firstName;

		    public String getfirstName() { return this.firstName.get(); }
		    public void setfirstName(String firstName) { this.firstName.set(firstName); }
		    public StringProperty firstNameProperty() {return this.firstName; }
		     
		    private StringProperty lastName;

		    public String getlastName() { return this.lastName.get(); }
		    public void setlastName(String lastName) { this.lastName.set(lastName); }
		    public StringProperty lastNameProperty() {return this.lastName; }
		    

		    public DataModel(String memberID,String firstName,String lastName){
		         this.memberID = new SimpleStringProperty(memberID);
		         this.firstName = new SimpleStringProperty(firstName);
		         this.lastName = new SimpleStringProperty(lastName);
		    }
	}
}
