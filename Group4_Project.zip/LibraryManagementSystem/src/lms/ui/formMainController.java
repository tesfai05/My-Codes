package lms.ui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.ResourceBundle;

import org.controlsfx.control.StatusBar;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.LoginException;
import lms.business.SystemController;
import lms.dataaccess.Auth;
import lms.dataaccess.User;

public class formMainController implements Initializable {

	@FXML
	private MenuBar mbMainForm;
	@FXML
	private Menu mMembers;
	@FXML
	private Menu mBooks;
	@FXML
	private Menu mSysAdmin;
	@FXML
	private Menu mCheckOut;
	@FXML
	private Menu mAuthor;

	@FXML
	private MenuItem miCreateMember;
	@FXML
	private MenuItem miEditMember;
	@FXML
	private MenuItem miViewMembers;
	@FXML
	private MenuItem miAuthor;
	@FXML
	private MenuItem miAbout;

	@FXML
	private TableView<String> view;
	@FXML
	private Button btnLoadData;

	@FXML
	private Button back;
	@FXML
	private MenuItem miaddBook, miviewBook, midamagedBook, miaddBookCopy;
	@FXML
	private MenuItem miCheckoutRecord, miReportCheckoutRecord, miOverDue;
	
	@FXML
	private StatusBar sbLoginHistory;

	@FXML
	public void createMemeber(ActionEvent event) throws IOException {
		ManageMembers(event, "Create Member");
	}

	public void ManageMembers(ActionEvent event, String sceneTitle) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMember.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle(sceneTitle);
		window.show();
	}

	public void EditMember(ActionEvent event) throws IOException {
		ManageMembers(event, "Edit Member");
	}

	public void manageAuthor(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formAuthor.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("Author Info");
		window.show();
	}
	private ObservableList getInitialTableData() {

		ControllerInterface c = new SystemController();
		List<LibraryMember> m = c.allMembers();

		ObservableList data = FXCollections.observableList(m);

		return data;
	}

	@FXML
	public void DisplayListOfMembers(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formListMembers.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("List Of Memeber");
		window.show();
	}

	@FXML
	public void aboutInfo(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formAbout.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("User Manaual");
		window.show();
	}

//     public void setData() {
//    	   ControllerInterface ci = new SystemController();
//			ObservableList<String> ids = (ObservableList<String>) ci.allBookIds();
//		
//    	 view.setItems(ids);
//     }
	public void SetPermissions() {
		switch (SystemController.currentAuth) {
		case ADMIN:

			mMembers.setDisable(false);
			mBooks.setDisable(false);
			mSysAdmin.setDisable(false);
			mCheckOut.setDisable(true);
			break;
		case LIBRARIAN:
			// librarian can only checkout books
			mMembers.setDisable(true);
			mBooks.setDisable(true);
			mSysAdmin.setDisable(true);
			mAuthor.setDisable(true);
			mCheckOut.setDisable(false);
			break;
		case BOTH:
			mCheckOut.setDisable(false);
			mMembers.setDisable(false);
			mBooks.setDisable(false);
			mSysAdmin.setDisable(false);
			break;
		default:
			throw new IllegalArgumentException("Unexpected value: " + SystemController.currentAuth);
		}

	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		SetPermissions();
		User currentUser = SystemController.currentUser;
		sbLoginHistory.setText(
				String.format("Current User: %s  and Last Login History: First time login", currentUser.getId()));
	}

	public void backButtonMethod(ActionEvent evt) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
		Scene general = new Scene(genWin);
		Stage wind = (Stage) ((Node) evt.getSource()).getScene().getWindow();
		wind.setScene(general);
		wind.show();

	}

//Books functionality
	public void addBookMethod(ActionEvent e) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formManageBook.fxml"));
		Scene general = new Scene(genWin,800,400);
		Stage wind = (Stage) mbMainForm.getScene().getWindow();
		
		wind.setScene(general);
		wind.setTitle("Manage Book Information");
		wind.show();
	}


	public void viewBookMethod(ActionEvent e) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formViewBooks.fxml"));
		Scene general = new Scene(genWin);
		Stage wind = (Stage) mbMainForm.getScene().getWindow();
		wind.setScene(general);
		wind.show();
	}


	public void damagedBookMethod(ActionEvent e) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formDamagedBooks.fxml"));
		Scene general = new Scene(genWin);
		Stage wind = (Stage) mbMainForm.getScene().getWindow();
		wind.setScene(general);
		wind.show();
	}

	public void addBookCopyMethod(ActionEvent e) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formAddBookCopy.fxml"));
		Scene general = new Scene(genWin);
		Stage wind = (Stage) mbMainForm.getScene().getWindow();
		wind.setScene(general);
		wind.show();
	}
	public void manageCheckoutRecord(ActionEvent e) throws IOException {
		Parent genWin = FXMLLoader.load(getClass().getResource("/lms/ui/formCheckOutBook.fxml"));
		Scene general = new Scene(genWin,800,400);
		Stage wind = (Stage) mbMainForm.getScene().getWindow();
		
		wind.setScene(general);
		wind.setTitle("Manage CheckoutRecords Information");
		wind.show();
	}
	@FXML
	public void DisplayListOfBooks(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formListBooks.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("List Of Books");
		window.show();
	}

	@FXML
	public void ReportCheckOutRecord(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formListOfCheckOutRecord.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("Book Checkout Report of Member");
		window.show();
	}
	public void ReportOverDue(ActionEvent event) throws IOException {
		Parent mainRoot;
		Scene MasterScene;
		// This will get the stage information
		Stage window = (Stage) mbMainForm.getScene().getWindow();
		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formOverDueBooks.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);

		window.setScene(MasterScene);
		window.setTitle("OverDue Books");
		window.show();
	}
}
