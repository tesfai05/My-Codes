package lms.ui;


import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.sun.glass.events.WindowEvent;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import lms.business.ControllerInterface;
import lms.business.SystemController;


public class formSelectAuthorController implements Initializable {
	
	
	
	@FXML
	private Button btnOk,btnCancel;
	@FXML
	private ComboBox<String> cbAuthors;
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ControllerInterface ci = new SystemController();
		List<String> ISBN=ci.allAuthorsId();
		cbAuthors.getItems().addAll(ISBN);
		
	}


	private Stage dialogStage;
	
	private boolean okClicked = false;

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	
	public boolean isOkClicked() {
		return okClicked;
	}
	public String getSelectedAuthor() {
		if (cbAuthors.getValue()!=null) {
			return cbAuthors.getValue().toString();
		}else
		{
			return null;
		}
	}
	@FXML
	private void handleOk() {
		if (cbAuthors.getValue()!=null) {
			
			okClicked = true;
			dialogStage.close();
		}
	}

	/**
	 * Called when the user clicks cancel.
	 */
	@FXML
	private void handleCancel() {
		dialogStage.close();
	}

	
}
