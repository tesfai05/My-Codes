package lms.ui;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import lms.business.Book;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.SystemController;
import lms.utils.Libraries;

public class formOverDueController implements Initializable{
	 @FXML
     private TableView<DataModel> view;
     @FXML
     private Button btnShow;
     @FXML 
     private Button btnCancel;
     @FXML
     private TextField txtSearchByISBN;

     @FXML
     private TableView<DataModel> myTableView;

     @FXML
     private TableColumn<DataModel, String> idISBN;
     @FXML
     private TableColumn<DataModel, String> idbookTitle;
     @FXML
     private TableColumn<DataModel, String> idMemberFullName;
     @FXML
     private TableColumn<DataModel, String> idCopyNumber;
     @FXML
     private TableColumn<DataModel, String> idReturnDate;
     
     @FXML
     public void onCancel(ActionEvent event) throws IOException {
    	Parent mainRoot;
 		Scene MasterScene;
 		// This will get the stage information
 		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
 		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);
		
 	 
		window.setScene(MasterScene);
		window.setTitle("Asmara Public Library");
		window.show();
		
		//Libraries.loadStage(event, this, "/lms/ui/formMain.fxml", "Asmara Public Center");
     }
     @FXML // This Will enable to return back to master form
 	public void showButtonClicked(ActionEvent event) {

 	}
     
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// use java naming conventions (`userId` instead of `UserId`)
		idISBN.setCellValueFactory(data -> data.getValue().ISBNProperty()); 
		 // same here user naming convention
		 idbookTitle.setCellValueFactory(data -> data.getValue().bookTitleProperty());
		 idMemberFullName.setCellValueFactory(data -> data.getValue().memberFullNameProperty());
		 idCopyNumber.setCellValueFactory(data -> data.getValue().copyNumberProperty());
		 idReturnDate.setCellValueFactory(data -> data.getValue().returnDateProperty());
		 myTableView.getItems().setAll(getItemsToAdd());
	}


	private ObservableList<DataModel> getItemsToAdd() {

		ControllerInterface ci = new SystemController();
		List<Book> list=ci.allbooks();
		ObservableList<DataModel> ids = FXCollections.observableArrayList();
	
		return ids;
	}
	class DataModel{
		  private StringProperty ISBN;

		    public String getISBN() { return this.ISBN.get(); }
		    public void setISBN(String ISBN) { this.ISBN.set(ISBN); }
		    public StringProperty ISBNProperty() { return this.ISBN; }

		    private StringProperty bookTitle;

		    public String getbookTitle() { return this.bookTitle.get(); }
		    public void setbookTitle(String bookTitle) { this.bookTitle.set(bookTitle); }
		    public StringProperty bookTitleProperty() {return this.bookTitle; }
		     
		    private StringProperty memberFullName;

		    public String getmemberFullName() { return this.memberFullName.get(); }
		    public void setmemberFullName(String memberFullName) { this.memberFullName.set(memberFullName); }
		    public StringProperty memberFullNameProperty() {return this.memberFullName; }
		    
		    private StringProperty copyNumber;

		    public String getcopyNumber() { return this.copyNumber.get(); }
		    public void setcopyNumber(String copyNumber) { this.copyNumber.set(copyNumber); }
		    public StringProperty copyNumberProperty() {return this.copyNumber; }

		    private StringProperty returnDate;

		    public String getreturnDate() { return this.returnDate.get(); }
		    public void setreturnDate(String returnDate) { this.returnDate.set(returnDate); }
		    public StringProperty returnDateProperty() {return this.returnDate; }

		    public DataModel(String memberFullName,String ISBN,String bookTitle,String copyNumber,String returnDate){
		         this.ISBN = new SimpleStringProperty(ISBN);
		         this.bookTitle = new SimpleStringProperty(bookTitle);
		         this.memberFullName = new SimpleStringProperty(memberFullName);
		         this.copyNumber = new SimpleStringProperty(copyNumber);
		         this.returnDate = new SimpleStringProperty(returnDate);
		    }
	}
}
