package lms.ui;

import lms.business.*;
import lms.ui.formListMembers.DataModel;
import lms.utils.Libraries;
import lms.utils.MessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.util.List;
import java.util.ResourceBundle;

public class formCheckOutBookController implements Initializable{
	
	@FXML
	private Label lblBookCopyNumber;
	
	@FXML
	private ComboBox  cbISBN,cbMemberId;
	
	@FXML
	private Text txtNumberofAvaliblies,txtFullNameMember;
	@FXML
	private TextField txtFine;
	
	@FXML
	private Button btnCheckOutRecord,btnCancel;
	@FXML
	private DatePicker dpBorrowDate,dpDueDate,dpReturnDate;
	@FXML
	private Text messageTextArea;
	@FXML
	private Text messageBar;
    @FXML
    private TableView<CheckoutModel> tabelView;
	
    @FXML
    public TableColumn<CheckoutModel, String> memberID;
    
   
    
    @FXML
    public TableColumn<CheckoutModel, String> bookTitle;
    @FXML
    public TableColumn<CheckoutModel, String> bookCopyNumber;
   
    @FXML
    public TableColumn<CheckoutModel, String> borrowDate;
    
    @FXML
    public TableColumn<CheckoutModel, String> dueDate;
    
    @FXML
    public TableColumn<CheckoutModel, String> returnDate;
 
    private String currentMemberID;
    private String currentBookCopyTobeReturned;
    String errorMessage=null;
	@FXML // This Will switch scene to master form
	public void cancelButtonClicked(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Asmara Public Library");
			window.show();

			// System.out.println("Login button clicked");
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
@FXML
public void checkInButtonClicked(ActionEvent event) {
	System.out.println("checking out book...........");
	//check return date should not equal to null
	
	ControllerInterface c=new SystemController();
	LibraryMember member= c.searchMemberById(cbMemberId.getValue().toString());
	
	CheckoutRecord record = member.getCheckoutRecord();;
			
	if(record!=null && dpReturnDate.getValue()!=null) {
		for (CheckoutEntry coe: record.getListOfUnreturnedBooks()) {
			if (currentBookCopyTobeReturned.equals(String.format("%s", coe.getBookCopy().getCopyNum()))) {
				coe.setReturnDate(LocalDateTime.of(dpReturnDate.getValue(),LocalTime.now()));
				//due date minus returned date is 
			    Period days=Period.between(dpReturnDate.getValue(), coe.getDueDate().toLocalDate());
				if (days.getDays()>0) {
					//the member must pay fine par day $3.2
					txtFine.setText(String.format("%s", days.getDays()*3.2));
					coe.setFine(true);
				}else
				{
					coe.setFine(false);
					txtFine.setText("0");
				}
				
			    member.setCheckoutRecord(record);
				c.saveCheckOutBook(member);
				Libraries.showAlert("Successfully.", "Book return successfully.", MessageType.CONFIRMATION, this);
			}
		}
	}else
		{
		Libraries.showAlert("Unsuccessfully.", "Please provide return date", MessageType.CONFIRMATION, this);
		return;				
	}
}
	@FXML // This Will process book checked out 
	public void checkoutButtonClicked(ActionEvent event) {
		
		System.out.println("checking out book...........");
		if (isInputValid()) return;
		String isbn = "";
		String memberId =null;
	
		memberId = (String) cbMemberId.getValue();
		isbn = (String) cbISBN.getValue();
		
		ControllerInterface c=new SystemController();
		Book b = c.searchBookById(isbn);
		LibraryMember member= c.searchMemberById(memberId);
		
		
		CheckoutRecord record = null;
				
		if(b.numberOfAvailableCopies() > 1) {
			try {
				c.checkoutBook(b, member);
				record = member.getCheckoutRecord();
				Libraries.showAlert("Successfull.", "You Sucessfully checked out a Book.", MessageType.CONFIRMATION, this);
				clearTextFields();
			} catch (Exception e) {
				Libraries.showAlert("UnSuccessfully.", "Unsuccessfuly saving data.", MessageType.CONFIRMATION, this);
			}		
		
					
		}else
		{
			Libraries.showAlert("Unsuccessfully.", "Book is not avaliable either one or zero.", MessageType.CONFIRMATION, this);
			return;				
		}
	
	}
	private boolean isInputValid() {
		String errorMessage = "";

		if (cbMemberId.getValue()==null) {
			
			errorMessage += "Please select memberID!\n";
		}
	
		if (errorMessage.length() == 0) {
			return false;
		} else {
			// Show the error message.
			
			Libraries.showAlert("Invalid Fields", errorMessage, MessageType.ERROR, null);
		
			return true;
		}
	}
   
    private void clearTextFields() {
    	dpBorrowDate.setDisable(false);
    	dpDueDate.setDisable(false);
    	dpReturnDate.setDisable(false);
    	dpDueDate.setDayCellFactory(null);
    	
    	tabelView.getItems().clear();
    	tabelView.getItems().setAll(getItemsToAdd(currentMemberID));
    	//messageTextArea.setText("");
    	errorMessage=null;
    }

    @SuppressWarnings("unchecked")
	@Override
    public void initialize(URL location, ResourceBundle resources) {
    	try {
    		//default value for borrowDate
        	dpBorrowDate.setValue(LocalDate.now());
        	dpReturnDate.setValue(LocalDate.now());
        	dpBorrowDate.setDisable(true);
        	dpDueDate.setDisable(true);
        	dpReturnDate.setDisable(true);
        	txtFine.setDisable(true);
        	
        	// use java naming conventions (`userId` instead of `UserId`)
        	memberID.setCellValueFactory(data -> data.getValue().memberIdProperty()); 
    		 // same here user naming convention
        	bookTitle.setCellValueFactory(data -> data.getValue().bookTitleProperty());
        	bookCopyNumber.setCellValueFactory(data -> data.getValue().bookCopyNumberProperty());
        	borrowDate.setCellValueFactory(data -> data.getValue().borrowDateProperty());
        	dueDate.setCellValueFactory(data -> data.getValue().dueDateProperty());
        	returnDate.setCellValueFactory(data -> data.getValue().returnDateProperty());
        
    		ControllerInterface ci = new SystemController();
    		List<String> ISBN=ci.allBookIds();
    		cbISBN.getItems().addAll(ISBN);
    		cbMemberId.getItems().addAll(ci.allMemberIds());
    		cbISBN.valueProperty().addListener(new ChangeListener<String>() {
    			@Override
    			public void changed(ObservableValue<? extends String> value, String old, String newValue) {
    				
    				Integer bookCopies=ci.getBookByISBN(newValue).getAllAvailableCopies().size();
    				//lblBookCopyNumber.setText("Check out book copy number of :"+ci);
    				txtNumberofAvaliblies.setText(String.format(ci.getBookByISBN(newValue).getTitle()+" has %d Number of Avaliable copies", bookCopies));
    				dpDueDate.setValue(dpBorrowDate.getValue().plusDays(ci.getBookByISBN(newValue).getMaxCheckoutLength()));
    			}});
    			cbMemberId.valueProperty().addListener(new ChangeListener<String>() {
    			@Override
    			public void changed(ObservableValue<? extends String> value, String old, String newValue) {
    				txtFullNameMember.setText("FullName :" + String.format(ci.searchMemberById(newValue).getFirstName()+" "+ ci.searchMemberById(newValue).getLastName()));
    				currentMemberID= cbMemberId.getValue().toString();
    				tabelView.getItems().setAll(getItemsToAdd(cbMemberId.getValue().toString()));
    			}});
    	
    			tabelView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener() {

    				@Override
    				public void changed(ObservableValue observableValue, Object oldValue, Object newValue) {
    					try {
    						CheckoutModel selectedItems = tabelView.getSelectionModel().getSelectedItems().get(0);
        					if (selectedItems!=null) {
        						messageTextArea.setText(String.format("Do you want to return the selected Book,with title:%s (%s)",selectedItems.getbookTitle(),selectedItems.getbookCopyNumber()));
        						currentBookCopyTobeReturned=String.format("%s", selectedItems.getbookCopyNumber());
        					}
						} catch (Exception e) {
							// TODO: handle exception
						}
    					
//    				
    				}
    			});
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    }
	private ObservableList<CheckoutModel> getItemsToAdd(String memberID) {

		ControllerInterface ci = new SystemController();
		LibraryMember member=ci.searchMemberById(memberID);
		ObservableList<CheckoutModel> ids = FXCollections.observableArrayList();
		for (CheckoutEntry coe : member.getCheckoutRecord().getEntries()) {
			CheckoutModel d=new CheckoutModel(memberID,coe.getBookCopy().getBook().getIsbn() + ":"+ 
			coe.getBookCopy().getBook().getTitle(),String.format("%s",coe.getBookCopy().getCopyNum()),coe.getBorrowDate().toString(),
					coe.getDueDate()==null?"":coe.getDueDate().toString(),
					coe.getReturnDate()==null ?"":coe.getReturnDate().toString());
			
			ids.add(d);
		}
		

		return ids;
	}
	
	class CheckoutModel{
		  private StringProperty memberID;

		    public String getMemberId() { return this.memberID.get(); }
		    public void setMemberId(String memberID) { this.memberID.set(memberID); }
		    public StringProperty memberIdProperty() { return this.memberID; }

		    private StringProperty bookTitle;

		    public String getbookTitle() { return this.bookTitle.get(); }
		    public void setbookTitle(String bookTitle) { this.bookTitle.set(bookTitle); }
		    public StringProperty bookTitleProperty() {return this.bookTitle; }
		     
		    private StringProperty bookCopyNumber;

		    public String getbookCopyNumber() { return this.bookCopyNumber.get(); }
		    public void setbookCopyNumber(String bookCopyNumber) { this.bookCopyNumber.set(bookCopyNumber); }
		    public StringProperty bookCopyNumberProperty() {return this.bookCopyNumber; }
		    
		    private  StringProperty borrowDate;
		    public String getborrowDate() { return this.borrowDate.get(); }
		    public void setborrowDate(String borrowDate) { this.borrowDate.set(borrowDate); }
		    public StringProperty borrowDateProperty() {return this.borrowDate; }

		    private  StringProperty dueDate;
		    public String getdueDate() { return this.dueDate.get(); }
		    public void setdueDate(String dueDate) { this.dueDate.set(dueDate); }
		    public StringProperty dueDateProperty() {return this.dueDate; }
		    
		    private  StringProperty returnDate;
		    public String getreturnDate() { return this.returnDate.get(); }
		    public void setreturnDate(String returnDate) { this.returnDate.set(returnDate); }
		    public StringProperty returnDateProperty() {return this.returnDate; }
		    public CheckoutModel() {
		    	
		    }
		    public CheckoutModel(String memberID,String bookTitle,String bookCopyNumber,String borrowDate,
		    		String dueDate,String returnDate){
		         this.memberID = new SimpleStringProperty(memberID);
		         this.bookTitle = new SimpleStringProperty(bookTitle);
		         this.bookCopyNumber = new SimpleStringProperty(bookCopyNumber);
		         this.borrowDate = new SimpleStringProperty(borrowDate);
		         this.dueDate = new SimpleStringProperty(dueDate);
		         this.returnDate = new SimpleStringProperty(returnDate);
		    }
	
	}
}
