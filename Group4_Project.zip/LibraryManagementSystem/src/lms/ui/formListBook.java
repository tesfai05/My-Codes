package lms.ui;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import lms.business.Book;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.SystemController;
import lms.utils.Libraries;

public class formListBook implements Initializable{
	 @FXML
     private TableView<DataModel> view;
     @FXML
     private Button btnLoadData;
     @FXML 
     private Button btnCancel;
     
     
     @FXML
     public void onCancel(ActionEvent event) throws IOException {
    	Parent mainRoot;
 		Scene MasterScene;
 		// This will get the stage information
 		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
 		mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
		MasterScene = new Scene(mainRoot, 600, 400);
		
 	 
		window.setScene(MasterScene);
		window.setTitle("Asmara Public Library");
		window.show();
		
		//Libraries.loadStage(event, this, "/lms/ui/formMain.fxml", "Asmara Public Center");
     }
     @FXML
     private TableView<DataModel> myTableView;

     @FXML
     private TableColumn<DataModel, String> idISBN;
     @FXML
     private TableColumn<DataModel, String> idbookTitle;
     @FXML
     private TableColumn<DataModel, String> idmaxCheckoutLength;
     @FXML
     private TableColumn<DataModel, String> idNumberOfCopies;
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// use java naming conventions (`userId` instead of `UserId`)
		idISBN.setCellValueFactory(data -> data.getValue().ISBNProperty()); 
		 // same here user naming convention
		 idbookTitle.setCellValueFactory(data -> data.getValue().bookTitleProperty());
		 idmaxCheckoutLength.setCellValueFactory(data -> data.getValue().maxCheckoutLengthProperty());
		 idNumberOfCopies.setCellValueFactory(data -> data.getValue().numberOfCopiesProperty());
	     myTableView.getItems().setAll(getItemsToAdd());
	}


	private ObservableList<DataModel> getItemsToAdd() {

		ControllerInterface ci = new SystemController();
		List<Book> list=ci.allbooks();
		ObservableList<DataModel> ids = FXCollections.observableArrayList();
		
		for (Book l : list) {
			 ids.add(new DataModel(l.getIsbn(),l.getTitle(),String.format("%s",l.getMaxCheckoutLength()),String.format("%s",l.getCopies().length)));
		}
			
		return ids;
	}
	class DataModel{
		  private StringProperty ISBN;

		    public String getISBN() { return this.ISBN.get(); }
		    public void setISBN(String ISBN) { this.ISBN.set(ISBN); }
		    public StringProperty ISBNProperty() { return this.ISBN; }

		    private StringProperty bookTitle;

		    public String getbookTitle() { return this.bookTitle.get(); }
		    public void setbookTitle(String bookTitle) { this.bookTitle.set(bookTitle); }
		    public StringProperty bookTitleProperty() {return this.bookTitle; }
		     
		    private StringProperty maxCheckoutLength;

		    public String getmaxCheckoutLength() { return this.maxCheckoutLength.get(); }
		    public void setmaxCheckoutLength(String maxCheckoutLength) { this.maxCheckoutLength.set(maxCheckoutLength); }
		    public StringProperty maxCheckoutLengthProperty() {return this.maxCheckoutLength; }
		    
		    private StringProperty numberOfCopies;

		    public String getnumberOfCopies() { return this.numberOfCopies.get(); }
		    public void setnumberOfCopies(String numberOfCopies) { this.numberOfCopies.set(numberOfCopies); }
		    public StringProperty numberOfCopiesProperty() {return this.numberOfCopies; }

		    public DataModel(String ISBN,String bookTitle,String maxCheckoutLength,String numberOfCopies){
		         this.ISBN = new SimpleStringProperty(ISBN);
		         this.bookTitle = new SimpleStringProperty(bookTitle);
		         this.maxCheckoutLength = new SimpleStringProperty(maxCheckoutLength);
		         this.numberOfCopies = new SimpleStringProperty(numberOfCopies);
		    }
	}
}
