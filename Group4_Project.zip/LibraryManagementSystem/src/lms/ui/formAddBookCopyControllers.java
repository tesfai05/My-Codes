package lms.ui;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import lms.business.Address;
import lms.business.Book;
import lms.business.BookCopy;
import lms.business.ControllerInterface;
import lms.business.LibraryMember;
import lms.business.LibrarySystemException;
import lms.business.SystemController;
import lms.utils.Libraries;
import lms.utils.MessageType;

public class formAddBookCopyControllers implements Initializable{
	@FXML
	private ToggleGroup Avaliable;
	@FXML
	private ComboBox<String> cbISBN;
	@FXML
	private TextField txtBookCopyNumber;
	@FXML
	private Text messageBar;
	@FXML
	private RadioButton rbYes, rbNo;
	@FXML
	private Button btnSave, btnEdit, btnDelete, btnCancel;
	@FXML
	private Text lblNumberbookCopies;
	String errorMessage;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		ControllerInterface ci = new SystemController();
		List<String> ISBN=ci.allBookIds();
		cbISBN.getItems().addAll(ISBN);
		//assign also availablity true
		rbYes.setSelected(true);
		cbISBN.valueProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> value, String old, String newValue) {
				// TODO Auto-generated method stub
				Integer bookCopies=ci.getBookByISBN(newValue).getCopies().length;
				
				lblNumberbookCopies.setText(String.format("%d", bookCopies));
			}});
	}
	
    
	public void Save() {
		System.out.println(".........Adding new Bookcopy .......");

		String isbn = cbISBN.getValue();
		
		if (DataValidation()==false) {
			messageBar.setFill(Color.FIREBRICK);
			messageBar.setText(errorMessage);
			
			return;
		}else {
			errorMessage=null;
			messageBar.setText(errorMessage);
		}
		
		int addCopiesOf=0;
	
		if (!txtBookCopyNumber.getText().isEmpty()) {
			addCopiesOf=Integer.parseInt(txtBookCopyNumber.getText());
		}
		
		boolean Avalibility=rbYes.isSelected()==true?true:false;
		

		ControllerInterface ci = new SystemController();
		Book b=null;
		b=ci.getBookByISBN(cbISBN.getValue().toString());
		for (int i = 0; i < addCopiesOf; i++) {
			b.addCopy();
		}
		ci.editbook(b);
		
		System.out.println(b);
		Libraries.showAlert("Success", "Bookcopy Inserted Successfully.", MessageType.CONFIRMATION,null);
		//clear all fields
		clearAllFields();
	}

	private boolean DataValidation() {
		try {
			if (txtBookCopyNumber.getText().isEmpty() ) {
				errorMessage = "Error : * Fields are required !";
				return false;
			} else {
				Integer.parseInt(txtBookCopyNumber.getText());
				
			}

		} catch (Exception e) {
			errorMessage = "Error : Invalid fields!";
			return false;
		}

		return true;
	}


	private void clearAllFields() {
		txtBookCopyNumber.setText("");
		rbYes.setSelected(true);
	}
	@FXML // This Will enable to return back to master form
	public void onCancelEvent(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Asmara Public Library");
			window.show();

			// System.out.println("Login button clicked");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
