package lms.ui;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import lms.business.ControllerInterface;
import lms.business.SystemController;

public class formListCheckOutRecord {
	
	@FXML
	private TextField checkoutRecord_memberID_TextField;
	@FXML
	private Text txtReport;
	
	@FXML
	private Button showMemberBtn;
	
	@FXML
	private Button cancelBtn;
	
	@FXML
	private Label noSuchMemberLabel;
	
	@FXML // This Will switch scene to master form
	public void cancelButtonClicked(ActionEvent event) {

		try {
			Parent mainRoot = FXMLLoader.load(getClass().getResource("/lms/ui/formMain.fxml"));
			Scene MasterScene = new Scene(mainRoot, 600, 400);

			// This will get the stage information
			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(MasterScene);
			window.setTitle("Master Form");
			window.show();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML //This Will display check out entries to console
	public void showButtonClicked(ActionEvent event) {
		ControllerInterface ci=new SystemController();
		
		int mId = 0;
		
		try {
			mId = Integer.parseInt(checkoutRecord_memberID_TextField.getText());
		}catch(NumberFormatException e) {
			noSuchMemberLabel.setText("Wrong Id Format (Enter a Number).");
			return;
		}
		
		System.out.println(".....display check out entries to console...........");
		if(!ci.findLibraryMemberByIdAndPrintCheckoutRecord(String.format("%s", mId))) {
			noSuchMemberLabel.setText("No member found.");
			txtReport.setText("");
		}else
		{
			txtReport.setText(ci.findLibraryMemberByIdAndPrintCheckoutRecordToUI(String.format("%s", mId)));
			noSuchMemberLabel.setText("");
		}
		
	}

}
